Name: Sarah Day
Date: 18 October 2019
Class: CSCI2467
Assignment: Upload the project 'RPSLSpock'.  Add JavaDoc comments, Unit testing, and push it to GitHub.